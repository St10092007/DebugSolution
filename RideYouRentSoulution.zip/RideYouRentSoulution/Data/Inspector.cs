﻿using Microsoft.AspNetCore.Identity;
using RideYouRentSoulution.Models;
using System.ComponentModel.DataAnnotations;

namespace RideYouRentSoulution.Data
{
    public class Inspector : IdentityUser
    {

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Inspector()
        {
            CarRental = new HashSet<CarRental>();
            CarRentalCollection = new HashSet<CarRentalCollection>();
            CarRentalReturn = new HashSet<CarRentalReturn>();
        }

        [Key]
        [StringLength(4)]
        public string Inspector_ID { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CarRental> CarRental { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CarRentalCollection> CarRentalCollection { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CarRentalReturn> CarRentalReturn { get; set; }
    }
}
