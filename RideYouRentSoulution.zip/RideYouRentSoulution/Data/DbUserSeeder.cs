﻿using Microsoft.AspNetCore.Identity;
using RideYouRentSoulution.Constants;

namespace RideYouRentSoulution.Data
{
    public static class DbUserSeeder
    {
        public static async Task SeedRolesAndAdminAsync(IServiceProvider service)
        {
            //Seed Roles
            var userManager = service.GetService<UserManager<Inspector>>();
            var roleManager = service.GetService<RoleManager<IdentityRole>>();
            await roleManager.CreateAsync(new IdentityRole(Roles.Admin.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Roles.Inspector.ToString()));

            // creating admin

            var user = new Inspector
            {
                UserName = "admin@gmail.com",
                Email = "admin@gmail.com",
                Name = "Halalisani Mdlalose",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            };
            var userInDb = await userManager.FindByEmailAsync(user.Email);
            if (userInDb == null)
            {
                // creating user with admin role. 
                await userManager.CreateAsync(user, "Admin@123");
                await userManager.AddToRoleAsync(user, Roles.Admin.ToString());
            }
        }
    }
}
