﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RideYouRentSoulution.Models;

namespace RideYouRentSoulution.Data
{
    public class ApplicationDbContext : IdentityDbContext<Inspector>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Car> Cars { get; set; }
        public virtual DbSet<CarBodyType> CarBodyType { get; set; }
        public virtual DbSet<CarRental> CarRental { get; set; }
        public virtual DbSet<CarRentalCollection> CarRentalCollection { get; set; }
        public virtual DbSet<CarRentalReturn> CarRentalReturn { get; set; }
        public virtual DbSet<CarMake> CarMakes { get; set; }
        public virtual DbSet<Driver> Drivers { get; set; }

    }
}