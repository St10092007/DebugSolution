﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RideYouRentSoulution.Migrations
{
    /// <inheritdoc />
    public partial class dbupdate2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Car_CarBodyType_CarBodyTypeBodytypeID",
                table: "Car");

            migrationBuilder.DropIndex(
                name: "IX_Car_CarBodyTypeBodytypeID",
                table: "Car");

            migrationBuilder.DropColumn(
                name: "CarBodyTypeBodytypeID",
                table: "Car");

            migrationBuilder.CreateIndex(
                name: "IX_Car_BodytypeID",
                table: "Car",
                column: "BodytypeID");

            migrationBuilder.AddForeignKey(
                name: "FK_Car_CarBodyType_BodytypeID",
                table: "Car",
                column: "BodytypeID",
                principalTable: "CarBodyType",
                principalColumn: "BodytypeID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Car_CarBodyType_BodytypeID",
                table: "Car");

            migrationBuilder.DropIndex(
                name: "IX_Car_BodytypeID",
                table: "Car");

            migrationBuilder.AddColumn<int>(
                name: "CarBodyTypeBodytypeID",
                table: "Car",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Car_CarBodyTypeBodytypeID",
                table: "Car",
                column: "CarBodyTypeBodytypeID");

            migrationBuilder.AddForeignKey(
                name: "FK_Car_CarBodyType_CarBodyTypeBodytypeID",
                table: "Car",
                column: "CarBodyTypeBodytypeID",
                principalTable: "CarBodyType",
                principalColumn: "BodytypeID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
