﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RideYouRentSoulution.Migrations
{
    /// <inheritdoc />
    public partial class CarUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CarRental_AspNetUsers_InspectorId",
                table: "CarRental");

            migrationBuilder.DropForeignKey(
                name: "FK_CarRental_Car_CarNo1",
                table: "CarRental");

            migrationBuilder.DropIndex(
                name: "IX_CarRental_CarNo1",
                table: "CarRental");

            migrationBuilder.DropColumn(
                name: "CarNo1",
                table: "CarRental");

            migrationBuilder.RenameColumn(
                name: "InspectorId",
                table: "CarRental",
                newName: "InspectorID");

            migrationBuilder.RenameIndex(
                name: "IX_CarRental_InspectorId",
                table: "CarRental",
                newName: "IX_CarRental_InspectorID");

            migrationBuilder.AlterColumn<string>(
                name: "InspectorID",
                table: "CarRental",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.CreateIndex(
                name: "IX_CarRental_CarNo",
                table: "CarRental",
                column: "CarNo");

            migrationBuilder.AddForeignKey(
                name: "FK_CarRental_AspNetUsers_InspectorID",
                table: "CarRental",
                column: "InspectorID",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_CarRental_Car_CarNo",
                table: "CarRental",
                column: "CarNo",
                principalTable: "Car",
                principalColumn: "CarNo",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CarRental_AspNetUsers_InspectorID",
                table: "CarRental");

            migrationBuilder.DropForeignKey(
                name: "FK_CarRental_Car_CarNo",
                table: "CarRental");

            migrationBuilder.DropIndex(
                name: "IX_CarRental_CarNo",
                table: "CarRental");

            migrationBuilder.RenameColumn(
                name: "InspectorID",
                table: "CarRental",
                newName: "InspectorId");

            migrationBuilder.RenameIndex(
                name: "IX_CarRental_InspectorID",
                table: "CarRental",
                newName: "IX_CarRental_InspectorId");

            migrationBuilder.AlterColumn<string>(
                name: "InspectorId",
                table: "CarRental",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CarNo1",
                table: "CarRental",
                type: "nvarchar(6)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_CarRental_CarNo1",
                table: "CarRental",
                column: "CarNo1");

            migrationBuilder.AddForeignKey(
                name: "FK_CarRental_AspNetUsers_InspectorId",
                table: "CarRental",
                column: "InspectorId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CarRental_Car_CarNo1",
                table: "CarRental",
                column: "CarNo1",
                principalTable: "Car",
                principalColumn: "CarNo",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
