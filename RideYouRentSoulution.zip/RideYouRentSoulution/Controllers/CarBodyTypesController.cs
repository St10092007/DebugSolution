﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RideYouRentSoulution.Data;
using RideYouRentSoulution.Models;

namespace RideYouRentSoulution.Controllers
{
    public class CarBodyTypesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarBodyTypesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CarBodyTypes
        public async Task<IActionResult> Index()
        {
              return _context.CarBodyType != null ? 
                          View(await _context.CarBodyType.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.CarBodyType'  is null.");
        }

        // GET: CarBodyTypes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.CarBodyType == null)
            {
                return NotFound();
            }

            var carBodyType = await _context.CarBodyType
                .FirstOrDefaultAsync(m => m.BodytypeID == id);
            if (carBodyType == null)
            {
                return NotFound();
            }

            return View(carBodyType);
        }

        // GET: CarBodyTypes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CarBodyTypes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CarBodytypeID,Type")] CarBodyType carBodyType)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carBodyType);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(carBodyType);
        }

        // GET: CarBodyTypes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.CarBodyType == null)
            {
                return NotFound();
            }

            var carBodyType = await _context.CarBodyType.FindAsync(id);
            if (carBodyType == null)
            {
                return NotFound();
            }
            return View(carBodyType);
        }

        // POST: CarBodyTypes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CarBodytypeID,Type")] CarBodyType carBodyType)
        {
            if (id != carBodyType.BodytypeID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carBodyType);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarBodyTypeExists(carBodyType.BodytypeID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(carBodyType);
        }

        // GET: CarBodyTypes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.CarBodyType == null)
            {
                return NotFound();
            }

            var carBodyType = await _context.CarBodyType
                .FirstOrDefaultAsync(m => m.BodytypeID == id);
            if (carBodyType == null)
            {
                return NotFound();
            }

            return View(carBodyType);
        }

        // POST: CarBodyTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.CarBodyType == null)
            {
                return Problem("Entity set 'ApplicationDbContext.CarBodyType'  is null.");
            }
            var carBodyType = await _context.CarBodyType.FindAsync(id);
            if (carBodyType != null)
            {
                _context.CarBodyType.Remove(carBodyType);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarBodyTypeExists(int id)
        {
          return (_context.CarBodyType?.Any(e => e.BodytypeID == id)).GetValueOrDefault();
        }
    }
}
