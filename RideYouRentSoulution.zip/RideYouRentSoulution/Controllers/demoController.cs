﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RideYouRentSoulution.Data;
using RideYouRentSoulution.Models;

namespace RideYouRentSoulution.Controllers
{
    public class demoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public demoController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: demo
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Cars.Include(c => c.CarBodyType).Include(c => c.CarMake);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: demo/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null || _context.Cars == null)
            {
                return NotFound();
            }

            var car = await _context.Cars
                .Include(c => c.CarBodyType)
                .Include(c => c.CarMake)
                .FirstOrDefaultAsync(m => m.CarNo == id);
            if (car == null)
            {
                return NotFound();
            }

            return View(car);
        }

        // GET: demo/Create
        public IActionResult Create()
        {
            ViewData["BodytypeID"] = new SelectList(_context.CarBodyType, "BodytypeID", "Type");
            ViewData["CarMakeID"] = new SelectList(_context.CarMakes, "CarMakeID", "Make");
            return View();
        }

        // POST: demo/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CarNo,Model,CarMakeID,BodytypeID,KilometresTravelled,ServiceKilometres,Available")] Car car)
        {
            if (ModelState.IsValid)
            {
                _context.Add(car);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["BodytypeID"] = new SelectList(_context.CarBodyType, "BodytypeID", "Type", car.BodytypeID);
            ViewData["CarMakeID"] = new SelectList(_context.CarMakes, "CarMakeID", "Make", car.CarMakeID);
            return View(car);
        }

        // GET: demo/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null || _context.Cars == null)
            {
                return NotFound();
            }

            var car = await _context.Cars.FindAsync(id);
            if (car == null)
            {
                return NotFound();
            }
            ViewData["BodytypeID"] = new SelectList(_context.CarBodyType, "BodytypeID", "Type", car.BodytypeID);
            ViewData["CarMakeID"] = new SelectList(_context.CarMakes, "CarMakeID", "Make", car.CarMakeID);
            return View(car);
        }

        // POST: demo/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("CarNo,Model,CarMakeID,BodytypeID,KilometresTravelled,ServiceKilometres,Available")] Car car)
        {
            if (id != car.CarNo)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(car);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarExists(car.CarNo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["BodytypeID"] = new SelectList(_context.CarBodyType, "BodytypeID", "Type", car.BodytypeID);
            ViewData["CarMakeID"] = new SelectList(_context.CarMakes, "CarMakeID", "Make", car.CarMakeID);
            return View(car);
        }

        // GET: demo/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null || _context.Cars == null)
            {
                return NotFound();
            }

            var car = await _context.Cars
                .Include(c => c.CarBodyType)
                .Include(c => c.CarMake)
                .FirstOrDefaultAsync(m => m.CarNo == id);
            if (car == null)
            {
                return NotFound();
            }

            return View(car);
        }

        // POST: demo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            if (_context.Cars == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Cars'  is null.");
            }
            var car = await _context.Cars.FindAsync(id);
            if (car != null)
            {
                _context.Cars.Remove(car);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarExists(string id)
        {
          return (_context.Cars?.Any(e => e.CarNo == id)).GetValueOrDefault();
        }
    }
}
