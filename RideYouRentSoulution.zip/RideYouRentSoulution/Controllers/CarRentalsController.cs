﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RideYouRentSoulution.Data;
using RideYouRentSoulution.Models;

namespace RideYouRentSoulution.Controllers
{
    public class CarRentalsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarRentalsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CarRentals
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.CarRental.Include(c => c.Driver);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: CarRentals/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.CarRental == null)
            {
                return NotFound();
            }

            var carRental = await _context.CarRental
                .Include(c => c.Driver)
                .FirstOrDefaultAsync(m => m.RentalID == id);
            if (carRental == null)
            {
                return NotFound();
            }

            return View(carRental);
        }

        // GET: CarRentals/Create
        public IActionResult Create()
        {
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "DriverName");
            return View();
        }

        // POST: CarRentals/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RentalID,DriverID,CarNo,ID,RentalFee,StartDate,EndDate")] CarRental carRental)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carRental);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "DriverName", carRental.DriverID);
            return View(carRental);
        }

        // GET: CarRentals/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.CarRental == null)
            {
                return NotFound();
            }

            var carRental = await _context.CarRental.FindAsync(id);
            if (carRental == null)
            {
                return NotFound();
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "DriverName", carRental.DriverID);
            return View(carRental);
        }

        // POST: CarRentals/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("RentalID,DriverID,CarNo,ID,RentalFee,StartDate,EndDate")] CarRental carRental)
        {
            if (id != carRental.RentalID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carRental);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarRentalExists(carRental.RentalID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "DriverName", carRental.DriverID);
            return View(carRental);
        }

        // GET: CarRentals/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.CarRental == null)
            {
                return NotFound();
            }

            var carRental = await _context.CarRental
                .Include(c => c.Driver)
                .FirstOrDefaultAsync(m => m.RentalID == id);
            if (carRental == null)
            {
                return NotFound();
            }

            return View(carRental);
        }

        // POST: CarRentals/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.CarRental == null)
            {
                return Problem("Entity set 'ApplicationDbContext.CarRental'  is null.");
            }
            var carRental = await _context.CarRental.FindAsync(id);
            if (carRental != null)
            {
                _context.CarRental.Remove(carRental);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarRentalExists(int id)
        {
          return (_context.CarRental?.Any(e => e.RentalID == id)).GetValueOrDefault();
        }
    }
}
