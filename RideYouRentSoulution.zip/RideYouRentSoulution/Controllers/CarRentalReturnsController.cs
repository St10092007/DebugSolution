﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RideYouRentSoulution.Data;
using RideYouRentSoulution.Models;

namespace RideYouRentSoulution.Controllers
{
    public class CarRentalReturnsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarRentalReturnsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CarRentalReturns
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.CarRentalReturn.Include(c => c.Driver);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: CarRentalReturns/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.CarRentalReturn == null)
            {
                return NotFound();
            }

            var carRentalReturn = await _context.CarRentalReturn
                .Include(c => c.Driver)
                .FirstOrDefaultAsync(m => m.ReturnID == id);
            if (carRentalReturn == null)
            {
                return NotFound();
            }

            return View(carRentalReturn);
        }

        // GET: CarRentalReturns/Create
        public IActionResult Create()
        {
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address");
            return View();
        }

        // POST: CarRentalReturns/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ReturnID,RentalID,CarNo,ID,DriverID,ReturnDate,ElapsedDate,Fine")] CarRentalReturn carRentalReturn)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carRentalReturn);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address", carRentalReturn.DriverID);
            return View(carRentalReturn);
        }

        // GET: CarRentalReturns/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.CarRentalReturn == null)
            {
                return NotFound();
            }

            var carRentalReturn = await _context.CarRentalReturn.FindAsync(id);
            if (carRentalReturn == null)
            {
                return NotFound();
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address", carRentalReturn.DriverID);
            return View(carRentalReturn);
        }

        // POST: CarRentalReturns/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ReturnID,RentalID,CarNo,ID,DriverID,ReturnDate,ElapsedDate,Fine")] CarRentalReturn carRentalReturn)
        {
            if (id != carRentalReturn.ReturnID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carRentalReturn);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarRentalReturnExists(carRentalReturn.ReturnID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address", carRentalReturn.DriverID);
            return View(carRentalReturn);
        }

        // GET: CarRentalReturns/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.CarRentalReturn == null)
            {
                return NotFound();
            }

            var carRentalReturn = await _context.CarRentalReturn
                .Include(c => c.Driver)
                .FirstOrDefaultAsync(m => m.ReturnID == id);
            if (carRentalReturn == null)
            {
                return NotFound();
            }

            return View(carRentalReturn);
        }

        // POST: CarRentalReturns/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.CarRentalReturn == null)
            {
                return Problem("Entity set 'ApplicationDbContext.CarRentalReturn'  is null.");
            }
            var carRentalReturn = await _context.CarRentalReturn.FindAsync(id);
            if (carRentalReturn != null)
            {
                _context.CarRentalReturn.Remove(carRentalReturn);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarRentalReturnExists(int id)
        {
          return (_context.CarRentalReturn?.Any(e => e.ReturnID == id)).GetValueOrDefault();
        }
    }
}
