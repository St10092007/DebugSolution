﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RideYouRentSoulution.Data;
using RideYouRentSoulution.Models;

namespace RideYouRentSoulution.Controllers
{
    public class CarRentalCollectionsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarRentalCollectionsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CarRentalCollections
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.CarRentalCollection.Include(c => c.Driver);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: CarRentalCollections/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.CarRentalCollection == null)
            {
                return NotFound();
            }

            var carRentalCollection = await _context.CarRentalCollection
                .Include(c => c.Driver)
                .FirstOrDefaultAsync(m => m.CollectionID == id);
            if (carRentalCollection == null)
            {
                return NotFound();
            }

            return View(carRentalCollection);
        }

        // GET: CarRentalCollections/Create
        public IActionResult Create()
        {
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address");
            return View();
        }

        // POST: CarRentalCollections/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CollectionID,RentalID,ID,DriverID,Address,Time")] CarRentalCollection carRentalCollection)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carRentalCollection);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address", carRentalCollection.DriverID);
            return View(carRentalCollection);
        }

        // GET: CarRentalCollections/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.CarRentalCollection == null)
            {
                return NotFound();
            }

            var carRentalCollection = await _context.CarRentalCollection.FindAsync(id);
            if (carRentalCollection == null)
            {
                return NotFound();
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address", carRentalCollection.DriverID);
            return View(carRentalCollection);
        }

        // POST: CarRentalCollections/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CollectionID,RentalID,ID,DriverID,Address,Time")] CarRentalCollection carRentalCollection)
        {
            if (id != carRentalCollection.CollectionID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carRentalCollection);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarRentalCollectionExists(carRentalCollection.CollectionID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["DriverID"] = new SelectList(_context.Drivers, "DriverID", "Address", carRentalCollection.DriverID);
            return View(carRentalCollection);
        }

        // GET: CarRentalCollections/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.CarRentalCollection == null)
            {
                return NotFound();
            }

            var carRentalCollection = await _context.CarRentalCollection
                .Include(c => c.Driver)
                .FirstOrDefaultAsync(m => m.CollectionID == id);
            if (carRentalCollection == null)
            {
                return NotFound();
            }

            return View(carRentalCollection);
        }

        // POST: CarRentalCollections/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.CarRentalCollection == null)
            {
                return Problem("Entity set 'ApplicationDbContext.CarRentalCollection'  is null.");
            }
            var carRentalCollection = await _context.CarRentalCollection.FindAsync(id);
            if (carRentalCollection != null)
            {
                _context.CarRentalCollection.Remove(carRentalCollection);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarRentalCollectionExists(int id)
        {
          return (_context.CarRentalCollection?.Any(e => e.CollectionID == id)).GetValueOrDefault();
        }
    }
}
