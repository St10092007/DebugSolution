﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using RideYouRentSoulution.Data;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RideYouRentSoulution.Models
{
    [Table("CarRentalReturn")]
    public class CarRentalReturn
    {
        [Key]
        public int ReturnID { get; set; }

        public int RentalID { get; set; }

        [Required]
        [StringLength(6)]
        public string CarNo { get; set; }

        [Required]
        [StringLength(4)]
        public string ID { get; set; }

        public int DriverID { get; set; }

        [Column(TypeName = "date")]
        public DateTime ReturnDate { get; set; }

        public int ElapsedDate { get; set; }

        public decimal Fine { get; set; }

        public virtual Car Car { get; set; }

        public virtual CarRental CarRental { get; set; }

        public virtual Driver Driver { get; set; }

        public virtual Inspector Inspector { get; set; }
    }
}
