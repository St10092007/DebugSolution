﻿using RideYouRentSoulution.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RideYouRentSoulution.Models
{
    [Table("CarRental")]
    public class CarRental
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CarRental()
        {
            CarRentalCollection = new HashSet<CarRentalCollection>();
            CarRentalReturn = new HashSet<CarRentalReturn>();
        }

        [Key]
        public int RentalID { get; set; }

        public int DriverID { get; set; }

        [Required]
        [StringLength(6)]
        public string CarNo { get; set; }

        [Required]
        [StringLength(4)]
        public string ID { get; set; }

        public decimal RentalFee { get; set; }

        [Column(TypeName = "date")]
        public DateTime StartDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime EndDate { get; set; }

        [ForeignKey("CarNo")]
        public virtual Car Car { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CarRentalCollection> CarRentalCollection { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CarRentalReturn> CarRentalReturn { get; set; }

        [ForeignKey("DriverID")]
        public virtual Driver Driver { get; set; }

        [ForeignKey("InspectorID")]
        public virtual Inspector Inspector { get; set; }
    }
}
