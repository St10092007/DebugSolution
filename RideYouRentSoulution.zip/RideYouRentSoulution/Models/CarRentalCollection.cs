﻿using RideYouRentSoulution.Data;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RideYouRentSoulution.Models
{
    [Table("CarRentalCollection")]

    public class CarRentalCollection
    {
        [Key]
        public int CollectionID { get; set; }

        public int RentalID { get; set; }

        [Required]
        [StringLength(4)]
        public string ID { get; set; }

        public int DriverID { get; set; }

        [Required]
        [StringLength(60)]
        public string Address { get; set; }

        public TimeSpan Time { get; set; }

        public virtual CarRental CarRental { get; set; }

        public virtual Inspector Inspector { get; set; }

        public virtual Driver Driver { get; set; }
    }
}
