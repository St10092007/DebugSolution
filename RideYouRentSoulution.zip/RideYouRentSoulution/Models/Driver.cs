﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace RideYouRentSoulution.Models
{
        
        [Table("Driver")]
        public partial class Driver
        {
            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
            public Driver()
            {
                CarRental = new HashSet<CarRental>();
                CarRentalCollection = new HashSet<CarRentalCollection>();
                CarRentalReturn = new HashSet<CarRentalReturn>();
            }

            [Key]
            public int DriverID { get; set; }

            [Required]
            [StringLength(50)]
            public string DriverName { get; set; }

            [Required]
            [StringLength(40)]
            public string Email { get; set; }

            [Required]
            [StringLength(100)]
            public string Address { get; set; }

            [Required]
            [Phone]    
            [StringLength(10)]
            public string Mobile { get; set; }

            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
            public virtual ICollection<CarRental> CarRental { get; set; }

            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
            public virtual ICollection<CarRentalCollection> CarRentalCollection { get; set; }

            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
            public virtual ICollection<CarRentalReturn> CarRentalReturn { get; set; }
        }
   

}
