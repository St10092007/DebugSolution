﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RideYouRentSoulution.Models
{
    [Table("CarMake")]
    public class CarMake
    {

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CarMake()
        {
            Cars = new HashSet<Car>();
        }

        [Key]
        public int CarMakeID { get; set; }

        [Required]
        [StringLength(15)]
        public string Make { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Car> Cars { get; set; }
    }
        
}
