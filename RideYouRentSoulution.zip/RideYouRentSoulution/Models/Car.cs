﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RideYouRentSoulution.Models
{
    [Table("Car")]
    public class Car
    {
        public Car()
        {
            CarRentalReturn = new HashSet<CarRentalReturn>();
            CarRental = new HashSet<CarRental>();
        }

        [Key]
        [StringLength(6)]
        public string CarNo { get; set; }

        [Required]
        [StringLength(30)]
        public string Model { get; set; }

        [ForeignKey("CarMake")]
        public int CarMakeID { get; set; }

        [ForeignKey("CarBodyType")]
        public int BodytypeID { get; set; }

        public int KilometresTravelled { get; set; }

        public int ServiceKilometres { get; set; }

        [StringLength(3)]
        public string Available { get; set; }

        public CarBodyType CarBodyType { get; set; }
        public CarMake CarMake { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CarRentalReturn> CarRentalReturn { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CarRental> CarRental { get; set; }
    }
}
