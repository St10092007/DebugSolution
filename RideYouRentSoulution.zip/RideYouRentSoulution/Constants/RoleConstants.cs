﻿namespace RideYouRentSoulution.Constants
{

    public enum Roles
    {
        Admin,
        Inspector
    }
    public class RoleConstants
    {
    }
}
